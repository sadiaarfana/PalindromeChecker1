﻿namespace Palindrome.Web.Models
{
    public  class APIConfig
    {
        public  string BaseURL { get; set; }
    }
}
